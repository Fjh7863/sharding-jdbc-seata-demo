package com.account.mapper;

import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:06
 */
public interface AccountMapper {

    Boolean account(@Param("userId") Long userId, @Param("money") BigDecimal money);

}
