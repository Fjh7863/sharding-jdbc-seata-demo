package com.account.feign;

import com.account.damain.Order;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/22 16:37
 */
@FeignClient(value = "order-service")
public interface OrderServiceFeign {

    @PostMapping("/order2")
    Boolean order2(@RequestBody Order order);
}
