package com.account.service.impl;

import com.account.damain.Order;
import com.account.feign.OrderServiceFeign;
import com.account.feign.StorageServiceFeign;
import com.account.mapper.AccountMapper;
import com.account.service.AccountService;
import io.seata.core.context.RootContext;
import org.apache.shardingsphere.transaction.annotation.ShardingTransactionType;
import org.apache.shardingsphere.transaction.core.TransactionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:05
 */
@Service
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private OrderServiceFeign orderServiceFeign;

    @Autowired
    private StorageServiceFeign storageServiceFeign;

    @ShardingTransactionType(TransactionType.BASE)
//    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean account(Long userId, BigDecimal money) {
        String xid = RootContext.getXID();
        System.out.println("account-service Current XID: " + xid);
        return accountMapper.account(userId, money);
    }

    @Transactional(rollbackFor = Exception.class)
    @ShardingTransactionType(TransactionType.BASE)
    @Override
    public Boolean test(Long userId, BigDecimal money) {
        storageServiceFeign.decrStorage(1L, 1);
        Order order = new Order();
        order.setCount(1);
        order.setMoney(money);
        order.setProductId(1L);
        order.setUserId(userId);
        order.setStatus(1);
        orderServiceFeign.order2(order);
        int i = 1 / 0;
        accountMapper.account(userId, money);
        return true;
    }
}
