package com.account.service;

import java.math.BigDecimal;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:04
 */
public interface AccountService {

    Boolean account(Long userId, BigDecimal money);

    Boolean test(Long userId, BigDecimal money);
}
