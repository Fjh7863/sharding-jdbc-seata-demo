package com.order.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/22 16:37
 */
@FeignClient(value = "account-service")
public interface AccountServiceFeign {

    @PostMapping("/account")
    Boolean account(@RequestParam("userId") Long userId, @RequestParam("money") BigDecimal money);
}
