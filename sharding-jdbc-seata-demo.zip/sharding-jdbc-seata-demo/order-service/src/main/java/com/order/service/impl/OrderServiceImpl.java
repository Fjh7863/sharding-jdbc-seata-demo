package com.order.service.impl;


import com.order.damain.Order;
import com.order.feign.AccountServiceFeign;
import com.order.feign.StorageServiceFeign;
import com.order.mapper.OrderMapper;
import com.order.service.OrderService;
import io.seata.core.context.RootContext;
import org.apache.shardingsphere.transaction.annotation.ShardingTransactionType;
import org.apache.shardingsphere.transaction.core.TransactionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:05
 */
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private AccountServiceFeign accountServiceFeign;

    @Autowired
    private StorageServiceFeign storageServiceFeign;

    @Transactional(rollbackFor = Exception.class)
    @ShardingTransactionType(TransactionType.BASE)
    @Override
    public Boolean order(Order order) {

        // 库存扣减
        Boolean storage = storageServiceFeign.decrStorage(order.getProductId(), order.getCount());

        // 账户扣减
        Boolean account = accountServiceFeign.account(order.getUserId(), order.getMoney());

        // 生成订单
        Long order1 = orderMapper.createOrder(order);

//        int i = 1 / 0;


        return Boolean.TRUE;
    }

//    @Transactional(rollbackFor = Exception.class)
    @ShardingTransactionType(TransactionType.BASE)
    @Override
    public Boolean order2(Order order) {
        String xid = RootContext.getXID();
        System.out.println("order-service Current XID: " + xid);
        Long order2 = orderMapper.createOrder(order);

        return true;
    }
}
