package com.order.controller;

import com.order.damain.Order;
import com.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:03
 */
@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/order")
    public Boolean order(@RequestBody Order order) {
        return orderService.order(order);
    }

    @PostMapping("/order2")
    public Boolean order2(@RequestBody Order order) {
        return orderService.order2(order);
    }
}
