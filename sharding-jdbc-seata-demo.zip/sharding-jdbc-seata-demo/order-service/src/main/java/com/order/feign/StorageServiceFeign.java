package com.order.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/22 16:37
 */
@FeignClient(value = "storage-service")
public interface StorageServiceFeign {

    @PostMapping("/decrStorage")
    Boolean decrStorage(@RequestParam("productId") Long productId, @RequestParam("count") Integer count);
}
