package com.order.damain;

import lombok.Data;

import java.math.BigDecimal;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/22 16:31
 */
@Data
public class Order {

    private Long id;

    private Long userId;

    private Long productId;

    private Integer count;

    private BigDecimal money;

    private Integer status;
}
