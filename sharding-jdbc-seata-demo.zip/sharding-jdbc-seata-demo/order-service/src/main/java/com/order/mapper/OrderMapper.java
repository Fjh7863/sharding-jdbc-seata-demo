package com.order.mapper;

import com.order.damain.Order;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:06
 */
public interface OrderMapper {

    Long createOrder(Order order);

}
