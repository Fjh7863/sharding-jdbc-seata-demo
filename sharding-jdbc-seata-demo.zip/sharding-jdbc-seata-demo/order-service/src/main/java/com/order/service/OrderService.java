package com.order.service;

import com.order.damain.Order;

import java.math.BigDecimal;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:04
 */
public interface OrderService {

    Boolean order(Order order);

    Boolean order2(Order order);
}
