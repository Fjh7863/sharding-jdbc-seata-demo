package com.storage.service;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:29
 */
public interface StorageService {
    Boolean decrStorage(Long productId, Integer count);
}
