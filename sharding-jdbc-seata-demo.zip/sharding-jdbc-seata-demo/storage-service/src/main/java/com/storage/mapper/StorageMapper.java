package com.storage.mapper;

import org.apache.ibatis.annotations.Param;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:30
 */
public interface StorageMapper {
    Boolean decrStorage(@Param("productId") Long productId, @Param("count") Integer count);
}
