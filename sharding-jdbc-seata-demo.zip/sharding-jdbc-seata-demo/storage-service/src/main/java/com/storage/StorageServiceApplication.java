package com.storage;

import io.seata.spring.boot.autoconfigure.SeataAutoConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan(basePackages = {"com.storage.mapper"})
@EnableAsync
@EnableScheduling
public class StorageServiceApplication {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(StorageServiceApplication.class);
        app.run(args);
    }
}
