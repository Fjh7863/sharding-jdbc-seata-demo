package com.storage.controller;

import com.storage.service.StorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:03
 */
@RestController
public class StorageController {

    @Autowired
    private StorageService storageService;

    @PostMapping("/decrStorage")
    public Boolean decrStorage(@RequestParam("productId") Long productId, @RequestParam("count") Integer count) {
        return storageService.decrStorage(productId, count);
    }
}
