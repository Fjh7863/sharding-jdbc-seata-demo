package com.storage.service.impl;

import com.storage.mapper.StorageMapper;
import com.storage.service.StorageService;
import groovy.transform.TailRecursive;
import io.seata.core.context.RootContext;
import org.apache.shardingsphere.transaction.annotation.ShardingTransactionType;
import org.apache.shardingsphere.transaction.core.TransactionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Author: FuJiaHao
 * Description:
 * Date: 2025/3/21 17:29
 */
@Service
public class StorageServiceImpl implements StorageService {

    @Autowired
    private StorageMapper storageMapper;

//    @Transactional(rollbackFor = Exception.class)
    @ShardingTransactionType(TransactionType.BASE)
    @Override
    public Boolean decrStorage(Long productId, Integer count) {
        String xid = RootContext.getXID();
        System.out.println("storage-service Current XID: " + xid);
        return storageMapper.decrStorage(productId, count);
    }
}
